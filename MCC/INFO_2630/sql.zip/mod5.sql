/******************
Module 5: Multiple table queries
INFO 2630
Written by Lisa Thoendel
Last Updated Fall 2021
Based on Ch 5 of A Guide to SQL 10th ed. by Shellman, Afyouni, Pratt & Last 
******************/

/******************
Completed by: 
Date:
******************/

--<<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>>--

use BikeStores;

-- 1) For each product, list the product id, name, price, category id and category name.
select p.product_id, p.product_name, p.list_price, p.category_id, c.category_name
from products p
join categories c on p.category_id = c.category_id
;

-- 2) For each staff member, list their first name, last name, phone number, store id and store name.
select a.first_name, a.last_name, a.phone, a.store_id, o.store_name
from staff a
join stores o on a.store_id = o.store_id
;

-- 3) Use the IN operator with a subquery to find the iD, name and list price for all products in the electric bikes, mountain bikes and road bikes categories.
select p.product_id, p.product_name, p.list_price
from products p
join categories c on p.category_id = c.category_id
where category_name in ('Electric Bikes', 'Mountain Bikes', 'Road Bikes')
;

-- 4) Repeat #3 but this time use the EXISTS operator in your solution.
select p.product_id, p.product_name, p.list_price
from products p
join categories c on p.category_id = c.category_id
where exists
(
	select category_name
	from categories c
	where category_name in ('Electric Bikes', 'Mountain Bikes', 'Road Bikes')
)
;

-- 5) For each store, show the store id, name and phone number along with the product name, id and quantity of products held at that store.
select r.store_id, r.store_name, r.phone, p.product_name, k.product_id, k.quantity
from stores r
join stocks k on r.store_id = k.store_id
join products p on k.product_id = p.product_id
;

-- 6) Repeat #5 but this time order the rows by store then by quantity from greatest to least.
select r.store_id, r.store_name, r.phone, p.product_name, k.product_id, k.quantity
from stores r
join stocks k on r.store_id = k.store_id
join products p on k.product_id = p.product_id
order by store_id, quantity desc
;

-- 7) Use a subquery to find the products that have only 1 of a particular product left in stock.
--		first find quantities of 1 in stock

--		use the product id col from stocks to show the products's whose info you want
select p.product_name, k.product_id, k.quantity
from products p
join stocks k on p.product_id = k.product_id
where quantity in
(
	select quantity
	from stocks k
	where quantity = 1
)
;

-- 8) Find the first name, last name and e-mail of all customers that currently have an order on file with Baldwin Bikes. Make use of at least one subquery.
select u.first_name, u.last_name, u.email
from customers u
join orders o on u.customer_id = o.customer_id
where store_id in
(
	select store_id
	from orders o
	where store_id =2
)
;

-- 9) List the order id, order date, ship date and store name for all orders for the customer Lizzie Joyner. Do not use any subqueries.
select o.order_id, o.order_date, o.shipped_date, r.store_name
from customers u
join orders o on u.customer_id = o.customer_id
join stores r on o.store_id = r.store_id
where u.first_name = 'Lizzie' and u.last_name = 'Joyner'
;

-- 10) List the quantity of stock each store has for the most expensive product we carry. Include the store name, product id, quantity, product name and price. 
--		Hint! use a subquery with max() to accomplish this.
select r.store_name, k.product_id, k.quantity, p.product_name, p.list_price
from products p
join stocks k on p.product_id = k.product_id
join stores r on k.store_id = r.store_id
where list_price in
(
	select max(list_price)
	from products p
)
;
