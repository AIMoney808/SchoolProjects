use BikeStores;
go

--#1
select customer_id, 
	concat (upper(first_name),' ', lower(last_name)) as full_name
from customers
;

--#2
select order_id, order_status,
	datediff (day, order_date, 2018-10-31) as days_past
from orders
;

--#3
select order_id, order_status,
	datediff (day, order_date, 2018-10-31) as days_past,
	dateadd(day, 90, order_date) as later_date
from orders
;

go
--#4
create or alter procedure Order_Lookup
@ordid int
as
select o.order_id, s.store_name, o.order_status, o.order_date,
	concat (first_name,' ', last_name) as full_name
from orders o
join customers c on o.customer_id = c.customer_id
join stores s on o.store_id = s.store_id
where order_id = @ordid
;

--#5
exec Order_Lookup '111';

go
--#6
create or alter procedure Product_Details
@prodets decimal(10,2)
as
declare @proid int
declare @pronam varchar(255)
declare @catnam varchar(255)
declare @branam varchar(255)
declare mycursor cursor read_only
for
select p.product_id, p.product_name, c.category_name, b.brand_name
from products p
join categories c on p.category_id = c.category_id
join brands b on p.brand_id = b.brand_id
where list_price = @prodets;

open mycursor
fetch next from mycursor
into @proid, @pronam, @catnam, @branam
while @@FETCH_STATUS = 0
begin
	print @proid + ' | ' + @pronam + ' | ' + @catnam + ' | ' + @branam
	fetch next from mycursor
	into  @proid, @pronam, @catnam, @branam
end

close mycursor
deallocate mycursor
;

--#7
exec Session_Length  >= '1000.00'
;