/******************
Module 6: Updating Data
INFO 2630
Written by Lisa Thoendel
Last Updated Fall 2021
******************/

--<<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>>--

use BikeStores;

-- Start by checking that implicit transactions are turned off: Tools > Options > Query Execution > SQL Server > ANSI > Set implicity_transactions should be unchecked

-- 1) Begin a transaction
begin transaction;

-- 2) Create a new_products table with the same structure as the productts table.
Drop table if exists new_products;
go
create table new_products (
	product_id INT PRIMARY KEY,
	product_name VARCHAR (255) NOT NULL,
	brand_id INT NOT NULL,
	category_id INT NOT NULL,
	model_year SMALLINT NOT NULL,
	list_price DECIMAL (10, 2) NOT NULL,
);

-- 3) Record your changes to the database
commit;

-- 4) insert into new_products the values from the products table for those products newer than 2018.
insert into new_products
select *
from products
where model_year > 2018
;

-- 5) begin a new transaction. add the following item to the new products table:
--		product_id: 399, product_name: Pee-wee Schwinn Western Flyer, brand_id: 8, category_id: 3, model_year: 2021, list_price: 36600.00
begin transaction
insert into new_products
values ( 399,'Pee-wee Schwinn Western Flyer', 8, 3, 2021, 36600.00)
;
-- 6) select everything from new products to see your inserted records
select *
from new_products;

-- 7) roll back the changes made by our transaction
rollback;

-- 8) select everything from noncat to see your inserted records
select *
from new_products;

-- 9) Delete every item in new productsion with a price under $2000
delete from new_products
where list_price < 2000
;

-- 10) in new products, discount the price of product number 320 by 20%.
update new_products
set list_price = (list_price * 0.80)
where product_id = 320
;

-- 11) add a column called dicontinued with a data type of char, length 1. set the value to 'N' for all rows.
alter table new_products
add discontinued char(1)
;
update new_products
set discontinued = 'N'
;

-- 12) in new products, decrease the length of the name field to 50 characters
alter table new_products
alter column product_name varchar(50);

-- 13) drop the new products table
drop table new_products;
