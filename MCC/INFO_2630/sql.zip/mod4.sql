/******************
Module 4: Single table queries
INFO 2630
Last Updated Fall 2021
******************/

/******************
Completed by: 
Date:
******************/

--<<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>>--

use BikeStores;

-- 1) List the first name, last name and phone number for all active staff.
select first_name, last_name, phone
from staff
where active = 1
;

-- 2) List the complete orders table (all rows & cols)
select *
from orders;

-- 3) List the last name and first name of every staff member who doesn't work at the flagship store (store #1).
select last_name, first_name
from staff
where store_id != 1
;

-- 4) List the product name and price for all products that cost 500 or less.
select product_name, list_price, category_id
from products
where list_price <= 500
;

-- 5) List the product name, price and category for all products that cost between $700 and $800.
select product_name, list_price, category_id
from products
where list_price between 700 and 800
;

-- 6) Find the category id for cruiser bikes. List the product name, price and category for all cruisers that cost less than $400.
select product_name, list_price, category_id
from products
where category_id = 3
	and list_price < 400
;
	
-- 7) A resort is interested in providing free bicycle use to their customers to use on surrounding trails. 
--		They would like to start with a fleet of 35 Electra Cruiser 1 Ladies' - 2018 (product id 220) bicycles.
--		List the product name, list price, order quantity (called quantity) and the calculated order price (called order_total) for the customer
select product_name, list_price, (35) as quantity, (35 * list_price) as order_total
from products
where product_id = 220
;

-- 8) List the customer information for all customers who live in El Paso, Houston, San Antonio and Garland.
select *
from customers
where (city in ('El Paso','Houston','San Antonio','Garland')) 
;

-- 9) Our resort customer is interested in inexpensive children's bike options. 
--		Find the category id for children's bikes
--		List the product id, product name and list price for children's bikes sorted lowest to highest by price.
select product_id, product_name, list_price
from products
where category_id = 1
order by list_price asc
;

-- 10) How many products do we offer in each product category?
select count(*) as product_count
from products
where (category_id in (1,2,3,4,5,6,7))
group by category_id
;
