/******************
Module 3: Creating Tables Assignment
INFO 2630
Last Updated Fall 2021
******************/

--<<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>>--

use BikeStores;

-- 1) Describe the customers table with sp_columns
exec sp_columns customers;

-- 2) Create a table named original_customers with the same columns as customers, except the customer_id is an int data type. 
CREATE TABLE original_customers (
	customer_id INT IDENTITY (1, 1) PRIMARY KEY,
	first_name VARCHAR (255) NOT NULL,
	last_name VARCHAR (255) NOT NULL,
	phone VARCHAR (25),
	email VARCHAR (255) NOT NULL,
	street VARCHAR (255),
	city VARCHAR (50),
	state VARCHAR (25),
	zip_code VARCHAR (5)
);

-- 3) Insert the first 50 customers from the customers table to the new table. Hint! You can order by the customer_id values <= 50 to pull this off! 
insert into original_customers (customer_id, first_name, last_name, phone, email, street, city, state, zip_code)
(
	select customer_id, first_name, last_name, phone, email, street, city, state, zip_code
	from customers
	where customer_id <= 50
);

-- 4) Add yourself to the original customers table as customer_id 51
insert into original_customers (customer_id, first_name, last_name, phone, email, street, city, state, zip_code)
values(51,'Aaron','Mahoney','(402)677-5460','aimahoney1@mail.mccneb.edu','837 Arlene Ave','Papillion','NE','68046');

-- 5) Display all the rows in the newly populated table.
select *
from original_customers;

-- Make note of the customer_id for Tangela Quinn: 
-- 

-- 6) Select Tangela's row from the table by her customer_id.
select *
from original_customers
where customer_id = 42;

-- 7) Update Tangela's record to include her phone number: 867-5309
update original_customers
set phone = '867-5309'
where customer_id = 42;

-- 8) Tangela won't answer our calls! Delete her row from the table.
delete
from original_customers
where customer_id = 42;

-- 9) Display all the rows to verify the deletion.
select *
from original_customers;

-- 10) Delete the original_customers table and all its rows from the database.
drop table original_customers;