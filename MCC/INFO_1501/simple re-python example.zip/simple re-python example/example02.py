import re

print("Example #2")

#open the file to read
file = open("barbertools.txt", "r")

#loop through the file object, one line at a time
for line in file:
        #only process lines that aren't blank
        if line != '\n':
            #looking for two adjacent numbers in each line
            result = re.findall(r'[0-9][0-9]', line)
            print(result)

file.close()

##printed output

##Example #2
##['68']
##['28']
##['29']
##[]
##['85']
##['85']
##['80']
##['80']

##notice that the [0-9][0-9] pattern didn't find
##a two number combination in the DISCONTINUED line.

##But the fetchall returns a list.
##So it returned an empty list and printed it.
