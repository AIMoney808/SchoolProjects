import re

print("Example #3")

#open the file to read
file = open("barbertools.txt", "r")

#loop through the file object, one line at a time
for line in file:
        #only process lines that aren't blank
        if line != '\n':
            #looking for two adjacent numbers in each line
            result = re.findall(r'[0-9][0-9]', line)
            #don't print if the result is an empty list
            if result != []:
                print(result)

file.close()

##printed output

##Example #3
##['68']
##['28']
##['29']
##['85']
##['85']
##['80']
##['80']

##We didn't print the empty list.
