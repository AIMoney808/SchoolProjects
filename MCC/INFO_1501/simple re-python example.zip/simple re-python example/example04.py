#The new database has been modified so we now have a hyphen between
#the two capital letters numbers and the numbers.
#The pattern looking for that is:
#result = re.findall(r'[A-Z]\-[0-9]{1,2}', line)
#That means "look for a capital letter, a hyphen, and one or two adjacent numbers"
#Notice how we escaped the hyphen symbol with a backslash

import re

print("Example #4")

#open the file to read
file = open("modifedbarbertools.txt", "r")

#loop through the file object, one line at a time
for line in file:
        #only process lines that aren't blank
        if line != '\n':
            #looking for a capital letter, a hyphen, and one or two adjacent numbers in each line
            result = re.findall(r'[A-Z]\-[0-9]{1,2}', line)
            #don't print if the result is an empty list
            if result != []:
                print(result)

file.close()

##printed output

##Example #4
##['A-68']
##['A-28']
##['A-29']
##['A-85']
##['A-85']
##['A-80']
##['A-80']

##We didn't print the empty list.
