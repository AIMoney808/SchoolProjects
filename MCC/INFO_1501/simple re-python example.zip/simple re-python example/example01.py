import re

print("Example #1")

#open the file to read
file = open("barbertools.txt", "r")

#loop through the file object, one line at a time
for line in file:
        #only process lines that aren't blank
        if line != '\n':
            #looking for two adjacent capital letters in each line
            result = re.findall(r'[A-Z][A-Z]', line)
            print(result)

file.close()

##printed output

##Example #1
##['PA']
##['MA']
##['MA']
##['DI', 'SC', 'ON', 'TI', 'NU', 'ED']
##['ZA']
##['ZA']
##['JA']
##['JA']

##Notice that the [A-Z][A-Z] pattern found a lot of two capital-letter
##combinations in the "DISCONTINUED" line.
